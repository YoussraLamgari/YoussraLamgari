you need to get your key at https://api.nasa.gov/ and put it in settings.py as a string with the name of key

it will save the image inside a folder named img inside the project folder
have fun!