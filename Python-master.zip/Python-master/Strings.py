String1 = 'Welcome to Malya\'s World'
print("String with the use of Single Quotes: ") 
print(String1) 
  
# Creating a String 
# with double Quotes 
String1 = "I'm a TechGeek"
print("\nString with the use of Double Quotes: ") 
print(String1) 
  
# Creating a String 
# with triple Quotes 
String1 = '''I'm Malya and I live in a world of "TechGeeks"'''
print("\nString with the use of Triple Quotes: ") 
print(String1) 
  
# Creating String with triple 
# Quotes allows multiple lines 
String1 = '''Smile 
            For 
            Life'''
print("\nCreating a multiline String: ") 
print(String1) 
