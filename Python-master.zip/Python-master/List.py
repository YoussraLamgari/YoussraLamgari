List = []
# List is Muteable
# means value can be change
List.insert(0 , 5)
List.insert(1,10)
List.insert(0,6)
print(List)
List.remove(6)
List.append(9)
List.append(1)
List.sort()
print(List)
List.pop()
List.reverse()
print(List)
"""
List.append(1)
print(List)
List.append(2)
print(List)
List.insert(1 , 3)
print(List)
"""
