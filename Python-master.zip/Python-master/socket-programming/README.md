# socket-programming-python
socket programming in python with client-server with duplex alternate chat(client-server-client-server-....) 

# Client 

![client](https://user-images.githubusercontent.com/29729380/55186437-8e9f0b00-51bc-11e9-86fa-5641143db32e.png)


# Server

![server](https://user-images.githubusercontent.com/29729380/55186445-92cb2880-51bc-11e9-9e67-40a9368cc6c7.png)
