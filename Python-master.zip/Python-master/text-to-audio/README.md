## Text To Audio

### We are using gtts module for conversion

Requirements: pip install gtts

#### Flow

gtts(Google Text To Speech)

1. Initialise the variable for your text ("mytext" line 6 in main.py)
2. Initialise the variable for language ("language" line 9 in main.py)
3. Create an instance of gTTS class ("myobj" line 12 in main.py)
4. Call the method save() and pass the filename that you want as a parameter (line 15 in main.py)
5. Play the audio file (line 19 in main.py)

#### NOTE
If you make any changes main.py, please mention it in README.md (this file). A better documentation makes the process of development faster.

---
Author - Saumitra Jagdale
 




