# JARVIS
patch-5<br>
Control windows programs with your voice.<br>
What can it do:<br>
1. Can tell you time.
2. Can open:<br>
    a) Notepad<br>
    b) Calculator<br>
    c) Sticky Note<br>
    d) PowerShell<br>
    e) MS Paint<br>
    f) cmd<br>
    g) Browser (Internet Explorer)<br>
    
It will make your experience better while using the Windows computer.
===========================================================================
It demonstrates Controlling windows programs with your voice.
