# master
# This program prints Hello, world!

import time
print("Hello I'm Geek! Let's Execute Your Code!")
time.sleep(1)
print("Starting Our Code!")
time.sleep(1)

print("Always Remember Python Is Case Sensitive!")
time.sleep(1)
print("Here We Go!")
time.sleep(1)
# master
print("Hello World!")
time.sleep(1)
print("A Quick Tip!")
time.sleep(1)
print("make sure to use the same type of quotes(quotation marks or apostrophes)at the end that you used at the start")

# in c -> printf("Hello World!");
# in java -> System.out.println("Hello World!");
# in c++ -> cout << "Hello World";
# master
# in javascript - > console.log("Hello World");

# in javascript - > console.log("Hello World") or document.write("Hello World!")
time.sleep(2)
print("All The Best!")
#Adios!
# master
