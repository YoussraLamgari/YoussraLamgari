! Notepad is a simple text editor

install notepad and sqlite3 using pip
